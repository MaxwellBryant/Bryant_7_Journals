/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prison_escape;

/**
 *
 * @author Max_and_a_Mango
 */
public class Blocked {
  

    public static boolean[][] blocked;

    public static boolean[][] getblocked() {

        return blocked;

    }

};

