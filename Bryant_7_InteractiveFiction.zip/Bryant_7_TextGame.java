package bryant_7_textgame;

import java.util.Scanner;

class player {

    int hp;
    String name;
}

class enemy {

    int hp;
    String name;
    String description;
}

public class Bryant_7_TextGame {

    static String Game;
    static int Potion = 1;
    static int SPotion;
    static boolean playagain = true;
    static player You = new player();
    static enemy Enemy = new enemy();

    public static void main(String[] args) {

        Scanner game = new Scanner(System.in);
        System.out.println("What is your name, hero?");
        You.name = game.nextLine();
        System.out.println("Hello, " + You.name + ", welcome to my game! "
                + "Type 'Start' to continue to the start screen.");
        truestart();
    }
    
    public static void truestart() {
        
        Scanner truestart = new Scanner(System.in);
        Game = truestart.nextLine();
        if (Game.contains("Start")) {
            System.out.println("When a dark breed of creatures crawled from underneath the surface, your father fought to stop them."
                    + " Something special about your bloodline alows you to defeat these dark creatures of the night."
                    + " Now that your father is dead, you must continue the bloodline...");
        }
        if (Game.contains("Start")) {
            System.out.println("Now, you have three options. Option 1 is to eat food, option 2 is to drink a potion, and option 3 is to journey on."
                    + " Please type 1, 2, or 3 to confirm your choice. Note that you only have 1 potion, so use it wisely!");
        }
        playgame();
    }

    public static void playgame() {

        You.hp = 100;
        Scanner play = new Scanner(System.in);
        Game = play.nextLine();
        if (Game.contains("3")) {
            System.out.println("You journey on, you aren't hungry then? Okay, disregaurd females, acquire currency, right? Legitimately though, you'll probably"
                    + " die hungry. (Just kidding, food doesn't do anything, it is just for show.)");
        } else if (Game.contains("2")) {
            System.out.println("You drink a potion and heal 20 hp, truly not the best choice right now...");
            You.hp += 20;
            Potion = 0;
        } else if (Game.contains("1")) {
            System.out.println("You don't starve for the night. Better now than later, right?");
        }
        queststart();
    }

    public static void queststart() {

        System.out.println("You are off on your quest to follow in your father's footsteps. "
                + "Suddenly, a quaint man in a cloak strolls up to you, blocking your path. "
                + "He asks you a riddle to solve to travel to the forest of where the dark monsters run free, for safety of course... "
                + "He asks, 'What travels up and down, but never moves?' You must answer this riddle.");
        q1();
    }

    public static void q1() {

        Scanner quest1 = new Scanner(System.in);
        Game = quest1.nextLine();
        if (Game.contains("Stairs")) {
            System.out.println("You are correct, the shady man lets you through to fight the beasts.");
        } else {
            System.out.println("You are incorrect, try again!");
            q1();
        }
        q2();
    }

    public static void q2() {

        Enemy.hp = 80;
        Scanner quest2 = new Scanner(System.in);
        System.out.println("Traveling in the forest, you encounter a hairy, blood-reeking werewolf! Type '1' to attack and type '2' to flee!");
        Game = quest2.nextLine();
        if (Game.contains("1")) {
            System.out.println("You slash at the beast, dealing 20 damage!");
            Enemy.hp -= 20;
            q2A();
        }
        if (Game.contains("2")) {
            System.out.println("You run from battle, your whole family shames you, and the world falls to corruption.");
            restart();
        }
    }

    public static void q2A() {

        Scanner quest2 = new Scanner(System.in);
        if (Enemy.hp != 0) {
            System.out.println("You must attack again! The werewolf has " + Enemy.hp + " HP left! Remember, type '1' to attack!");
        }
        Game = quest2.nextLine();
        if (Enemy.hp == 0) {
            System.out.println("You have struck down the werewolf! Congratulations! If you wish, you may drink a potion by typing 'Potion', "
                    + "if not, type 'Onward' to continue to the next beast. Remember, you only have ONE potion, and you currently have "
                    + You.hp + " HP left, good luck.");
            q3();
        } else if (Game.contains("1")) {
            System.out.println("You slash at the beast again, dealing another 20 damage!");
            Enemy.hp -= 20;
            q2B();
        }
    }

    public static void q2B() {

        Scanner quest2 = new Scanner(System.in);
        System.out.println("The werewolf attacks you back! His slash is weak, but you can't take too much, you lose 10 HP.");
        You.hp -= 10;
        q2A();
        Game = quest2.nextLine();
        if (You.hp == 0) {
            System.out.println("The werewolf takes a final slash at your weak, doll-like body. He eats you barely alive until you bleed out and die.");
            restart();
        }
    }

    public static void q3() {

        Scanner quest3 = new Scanner(System.in);
        Game = quest3.nextLine();
        if (Game.contains("Potion")) {
            System.out.println("You drink a potion and heal 20 HP. Type 'Onward' to continue!");
            if (Potion == 1) {
                You.hp += 20;
                q3A();
            } else {
                System.out.println("Why did you try to cheat? You are a shame to this game! You will lose 30 HP because I hate you now.");
                You.hp -= 30;
                q3A();
            }
        }
    }

    public static void q3A() {

        Enemy.hp = 100;
        Scanner quest3 = new Scanner(System.in);
        Game = quest3.nextLine();
        if (Game.contains("Onward")) {
            System.out.println("You continue your quest to push back the darkness. Suddenly, you encounter a strange ghostly figure! "
                    + "Type '1' to attack or '2' to flee!");
        }
        Game = quest3.nextLine();
        if (Game.contains("2")) {
            System.out.println("You flee from the strange ghost. You don't even make it home before the darkness spreads beyond control.");
            restart();
        } else if (Game.contains("1")) {
            System.out.println("You attack the ghost, dealing 20 damage!");
            Enemy.hp -= 20;
            q3B();
        }
    }

    public static void q3B() {

        Scanner quest3 = new Scanner(System.in);
        if (Enemy.hp != 0) {
            System.out.println("You must attack again! The ghost has " + Enemy.hp + " HP left! Remember, type '1' to attack!");
        }
        Game = quest3.nextLine();
        if (Enemy.hp == 0) {
            System.out.println("You have struck down the strange ghost! You have also found a Strong Potion! "
                    + "You currently have " + You.hp + " HP. If you wish, you may use the Strong Potion by typing 'S Potion', "
                    + "if not, then you will surely die, the boss is next.");
            SPotion += 1;
            questend();
        } else if (Game.contains("1")) {
            System.out.println("You slash at the figure again, dealing another 20 damage!");
            Enemy.hp -= 20;
            q3C();
        }
    }

    public static void q3C() {

        Scanner quest3 = new Scanner(System.in);
        System.out.println("The ghost teleports and attacks back! You lose 15 HP, don't die!");
        You.hp -= 15;
        q3B();
        Game = quest3.nextLine();
        if (You.hp == 0) {
            System.out.println("The ghost disappears, the next thing you see is a large set of teeth sinking in. You die almost instantly.");
            restart();
        }
    }

    public static void questend() {

        Enemy.hp = 120;
        Scanner questend = new Scanner(System.in);
        Game = questend.nextLine();
        if (Game.contains("S Potion")) {
            System.out.println("You use the Strong Potion and heal 50 HP. Type 'Boss' to continue to the final boss.");
            You.hp += 50;
            SPotion = 0;
        }
        Game = questend.nextLine();
        if (Game.contains("Boss")) {
            System.out.println("You step into the cavern where the dark warlock resides, if you defeat him, the darkness will have no leader. "
                    + "Defeat the boss with '1' to attack; there's no time to run now, you must finish it.");
        }
        Game = questend.nextLine();
        if (Game.contains("1")) {
            System.out.println("You attack the agile warlock. That strong potion must have upgraded your strength, you deal 40 damage!");
            Enemy.hp -= 40;
            questend2();
        }
        if (Game.contains("2")) {
            System.out.println("No! You must fight! Backing out now will result in death! Those were the last words you heard in your head "
                    + "as the warlock teleported you to a parallel universe and left you to die a cold, blackened life.");
            restart();
        }
    }
    
    public static void questend2() {
        
        Scanner questend = new Scanner(System.in);
        if (Enemy.hp != 0) {
            System.out.println("You must attack again! The boss has " + Enemy.hp + " HP left!");
        }
        Game = questend.nextLine();
        if (Enemy.hp == 0) {
            System.out.println("You defeat the warlock! The darkness is easily dimished without their leader. Your father would be proud. "
                    + "Afterall, he died trying to do this. The village rejoices and creates statues in your honor. You did good, " + You.name + ", "
                    + "you did good. To show the epilouge, type 'Epi'. Thank you for playing my game!");
            epilouge();
        }
        else if (Game.contains("1")) {
            System.out.println("You lauch yourself at the warlock to attack again, you deal 40 damage!");
            Enemy.hp -= 40;
            questboss();
        }
    }
    
    public static void questboss() {
        
        Scanner questend = new Scanner(System.in);
        System.out.println("The warlock grows larger and attacks you with a powerful blow! You lose 30 HP.");
        You.hp -= 30;
        questend2();
        Game = questend.nextLine();
        if (You.hp == 0) {
            System.out.println("The warlock grabs hold of you and rips you apart. Blood hit the floor in large puddles, and the darkness wins again.");
            restart();
        }
    }
    
    public static void epilouge() {
        
        Scanner epilouge = new Scanner(System.in);
        Game = epilouge.nextLine();
        if (Game.contains("Epi")) {
            System.out.println("Your family lives a life of great wealth and power given to you by the village. It is rather odd though, "
                    + "your bloodline lost the ability to see these creatures, just ensuring that you truly defeated the dark. "
                    + "All of this time, you wondered how many times your father and the fathers before him have died doing this. "
                    + "You live peacefully and happily for the rest of your life, and you know your son will too.");
            System.exit(0);
        }
    }
    
    public static void restart() {
        
        Scanner restart = new Scanner(System.in);
        System.out.println("What is your name, young one?");
        You.name = restart.nextLine();
        System.out.println("Greetings, " + You.name + ", welcome to my game, again. Your father has passed, you must take his place. Best of luck to you. "
                + "Remember to type 'Start' to begin!");
        truestart();
    }
}
